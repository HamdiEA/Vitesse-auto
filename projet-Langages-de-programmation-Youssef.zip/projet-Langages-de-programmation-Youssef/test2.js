import express from 'my-express-app';

const app = express();
const PORT = 3000;

// Replace with your ExchangeRates API key
const API_KEY = "eb5320e85636e22cc1b52a27e8095fa4";
const BASE_URL = "https://api.exchangeratesapi.io/latest"; // Change if using another provider

app.get("/exchange-rate/usd-to-eur", async (req, res) => {
    try {
        const response = await fetch(`${BASE_URL}?access_key=${API_KEY}&base=USD&symbols=EUR`);
        const data = await response.json();

        if (data.rates && data.rates.EUR) {
            res.json({ USD_to_EUR: data.rates.EUR });
        } else {
            res.status(500).json({ error: "Failed to retrieve USD to EUR rate" });
        }
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch exchange rate" });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
